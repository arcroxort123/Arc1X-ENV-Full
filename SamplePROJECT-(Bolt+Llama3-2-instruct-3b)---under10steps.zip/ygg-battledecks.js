import * as THREE from 'three';

    class YggBattleDecks {
      constructor() {
        this.yggdrasil = {};
        this.dragonAux = {};
        this.dragonPlatforms = {};
      }

      implementYggBattleDecks() {
        // Implement ygg-battledecks
      }
    }

    const yggBattleDecks = new YggBattleDecks();
