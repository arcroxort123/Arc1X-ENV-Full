import React from 'react';
    import ReactDOM from 'react-dom';
    import { Canvas } from '@react-spring/canvas';
    import * as THREE from 'three';

    const App = () => {
      return (
        <Canvas
          width={800}
          height={600}
          style={{ border: '1px solid black' }}
        >
          {/* Scene Management System */}
          <Scene>
            <Camera position={[0, 5, -10]} />
            <Light position={[10, 10, 10]} />
            <Mesh ref={(mesh) => mesh.position.set(0, 0, 0)} geometry={new THREE.BoxGeometry()} material={new THREE.MeshBasicMaterial({ color: 0x00ff00 })} />
          </Scene>
        </Canvas>
      );
    };

    ReactDOM.render(<App />, document.getElementById('root'));
