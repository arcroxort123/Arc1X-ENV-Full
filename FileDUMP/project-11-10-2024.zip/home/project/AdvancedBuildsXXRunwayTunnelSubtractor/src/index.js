import { createAdvancedBuildsXXRunwayTunnelSubtractor } from 'advancedbuildsxrunwattunsubtractordk';

    const advancedBuildsXXRunwayTunnelSubtractor = createAdvancedBuildsXXRunwayTunnelSubtractor({
      name: 'Invisible Sun',
      description: 'An advanced build xx runway tunnel subtractor for the Invisible Sun'
    });

    advancedBuildsXXRunwayTunnelSubtractor.start();
