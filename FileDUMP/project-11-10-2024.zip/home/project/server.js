const express = require('express');

    class Server {
      constructor() {
        this.app = express();
      }

      start() {
        // Start the server
        const port = 3000;
        this.app.listen(port, () => {
          console.log(`Server started on port ${port}`);
        });
      }
    }

    module.exports = Server;
