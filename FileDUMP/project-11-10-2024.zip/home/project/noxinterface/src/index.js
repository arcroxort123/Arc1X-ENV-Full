import { createNox } from 'nox-sdk';

    const nox = createNox({
      name: 'Invisible Sun',
      description: 'A nox interface for the Invisible Sun'
    });

    nox.start();
