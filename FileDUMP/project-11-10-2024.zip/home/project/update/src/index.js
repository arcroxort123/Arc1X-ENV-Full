import { createUpdate } from 'update-sdk';

    const update = createUpdate({
      name: 'Invisible Sun',
      description: 'An update for the Invisible Sun'
    });

    update.start();
