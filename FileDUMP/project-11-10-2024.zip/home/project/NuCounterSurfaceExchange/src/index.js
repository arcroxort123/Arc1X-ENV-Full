import { createNuCounterSurfaceExchange } from 'nucountersurfacexchange sdk';

    const nuCounterSurfaceExchange = createNuCounterSurfaceExchange({
      name: 'Invisible Sun',
      description: 'A Nu Counter Surface Exchange for the Invisible Sun'
    });

    nuCounterSurfaceExchange.start();
