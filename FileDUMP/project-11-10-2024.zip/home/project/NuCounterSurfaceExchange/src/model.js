class NuCounterSurfaceExchange {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with Nu Counter Surface Exchange measures
        const server = require('./server');
        server.nucountersurfacexchange();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with Nu Counter Surface Exchange measures
        const frontend = require('./frontend');
        frontend.nucountersurfacexchange();
        this.setState({ frontend });
      }
    }

    module.exports = NuCounterSurfaceExchange;
