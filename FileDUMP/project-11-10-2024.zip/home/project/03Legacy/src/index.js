import { createLegacy } from 'legacydk';

    const legacy = createLegacy({
      name: 'Invisible Sun',
      description: 'A legacy for the Invisible Sun'
    });

    legacy.start();
