import { createAiTheoryReactor } from 'aithytheoryreactorkdk';

    const aiTheoryReactor = createAiTheoryReactor({
      name: 'Invisible Sun',
      description: 'An ai theory reactor for the Invisible Sun'
    });

    aiTheoryReactor.start();
