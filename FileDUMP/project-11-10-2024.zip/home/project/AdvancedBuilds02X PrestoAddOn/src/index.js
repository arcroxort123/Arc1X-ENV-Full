import { createAdvancedBuilds02XPrestoAddOn } from 'advancedbuilds02xprestoaddondk';

    const advancedBuilds02XPrestoAddOn = createAdvancedBuilds02XPrestoAddOn({
      name: 'Invisible Sun',
      description: 'An advanced build 02 xp resto add on for the Invisible Sun'
    });

    advancedBuilds02XPrestoAddOn.start();
