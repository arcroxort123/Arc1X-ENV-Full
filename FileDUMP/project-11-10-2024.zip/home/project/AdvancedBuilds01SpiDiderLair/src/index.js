import { createAdvancedBuilds01SpiDiderLair } from 'advancedbuilds01spididerlairdk';

    const advancedBuilds01SpiDiderLair = createAdvancedBuilds01SpiDiderLair({
      name: 'Invisible Sun',
      description: 'An advanced build 01 spi dider lair (actual code) for the Invisible Sun'
    });

    advancedBuilds01SpiDiderLair.start();
