class 04WipExtrasRemissionChapter4PeripherealGrailExtPhases {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with periphereal grail ext phases measures
        const server = require('./server');
        server.04wipextrasremissionchapter4peripherealgrielextphases();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with periphereal grail ext phases measures
        const frontend = require('./frontend');
        frontend.04wipextrasremissionchapter4peripherealgrielextphases();
        this.setState({ frontend });
      }
    }

    module.exports = 04WipExtrasRemissionChapter4PeripherealGrailExtPhases;
