import { create04WipExtrasRemissionChapter4PeripherealGrailExtPhases } from '04wipextrasremissionchapter4peripherealgrielextphasedk';

    const 04WipExtrasRemissionChapter4PeripherealGrailExtPhases = create04WipExtrasRemissionChapter4PeripherealGrailExtPhases({
      name: 'Invisible Sun',
      description: 'A periphereal grail ext phases for the 04 Wip Extras Remission Chapter 4'
    });

    04WipExtrasRemissionChapter4PeripherealGrailExtPhases.start();
