class 04WipExtrasRemissionChapter10BeaconToBouquet {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with beacon to bouquet measures
        const server = require('./server');
        server.04wipextrasremissionchapter10beacontobouquet();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with beacon to bouquet measures
        const frontend = require('./frontend');
        frontend.04wipextrasremissionchapter10beacontobouquet();
        this.setState({ frontend });
      }
    }

    module.exports = 04WipExtrasRemissionChapter10BeaconToBouquet;
