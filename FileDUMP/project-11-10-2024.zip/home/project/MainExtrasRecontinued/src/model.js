class MainExtrasRecontinued {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with recontinued measures
        const server = require('./server');
        server.mainextrasrecontinued();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with recontinued measures
        const frontend = require('./frontend');
        frontend.mainextrasrecontinued();
        this.setState({ frontend });
      }
    }

    module.exports = MainExtrasRecontinued;
