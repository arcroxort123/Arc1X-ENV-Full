import { createMainExtrasRecontinued } from 'mainextrasrecontinueddk';

    const mainExtrasRecontinued = createMainExtrasRecontinued({
      name: 'Invisible Sun',
      description: 'A recontinued for the MAIN Extras'
    });

    mainExtrasRecontinued.start();
