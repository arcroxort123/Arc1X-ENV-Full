class MainExtrasReferencesRemissionContinuedEdition {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with continued edition measures
        const server = require('./server');
        server.mainextrasreferencesremissioncontinuededition();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with continued edition measures
        const frontend = require('./frontend');
        frontend.mainextrasreferencesremissioncontinuededition();
        this.setState({ frontend });
      }
    }

    module.exports = MainExtrasReferencesRemissionContinuedEdition;
