import { createMainExtrasReferencesRemissionContinuedEdition } from 'mainextrasreferencesremissioncontinuededitiondk';

    const mainExtrasReferencesRemissionContinuedEdition = createMainExtrasReferencesRemissionContinuedEdition({
      name: 'Invisible Sun',
      description: 'A continued edition for the MAIN Extras References (Remission)'
    });

    mainExtrasReferencesRemissionContinuedEdition.start();
