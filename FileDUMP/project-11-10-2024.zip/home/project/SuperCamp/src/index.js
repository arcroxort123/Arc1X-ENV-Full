import { createSuperCamp } from 'supercampdk';

    const superCamp = createSuperCamp({
      name: 'Invisible Sun',
      description: 'A super camp for the Invisible Sun'
    });

    superCamp.start();
