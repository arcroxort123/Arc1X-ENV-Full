import { createAdvancedBuilds09QuantumReadyComputationProfile } from 'advancedbuilds09quantumreadycomputationprofiledk';

    const advancedBuilds09QuantumReadyComputationProfile = createAdvancedBuilds09QuantumReadyComputationProfile({
      name: 'Invisible Sun',
      description: 'An advanced build 09 quantum ready computation profile for the Invisible Sun'
    });

    advancedBuilds09QuantumReadyComputationProfile.start();
