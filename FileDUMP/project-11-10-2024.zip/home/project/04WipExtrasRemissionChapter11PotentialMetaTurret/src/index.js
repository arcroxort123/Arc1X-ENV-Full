import { create04WipExtrasRemissionChapter11PotentialMetaTurret } from '04wipextrasremissionchapter11potentialmetaturretdk';

    const 04WipExtrasRemissionChapter11PotentialMetaTurret = create04WipExtrasRemissionChapter11PotentialMetaTurret({
      name: 'Invisible Sun',
      description: 'A potential meta turret for the 04 Wip Extras Remission Chapter 11'
    });

    04WipExtrasRemissionChapter11PotentialMetaTurret.start();
