class 04WipExtrasRemissionChapter7Thermals {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with thermals measures
        const server = require('./server');
        server.04wipextrasremissionchapter7thermals();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with thermals measures
        const frontend = require('./frontend');
        frontend.04wipextrasremissionchapter7thermals();
        this.setState({ frontend });
      }
    }

    module.exports = 04WipExtrasRemissionChapter7Thermals;
