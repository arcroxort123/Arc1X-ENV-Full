import { create04WipExtrasRemissionChapter7Thermals } from '04wipextrasremissionchapter7thermaldk';

    const 04WipExtrasRemissionChapter7Thermals = create04WipExtrasRemissionChapter7Thermals({
      name: 'Invisible Sun',
      description: 'A thermals for the 04 Wip Extras Remission Chapter 7'
    });

    04WipExtrasRemissionChapter7Thermals.start();
