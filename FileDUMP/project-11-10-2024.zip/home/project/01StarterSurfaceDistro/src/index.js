import { createStarterSurfaceDistro } from 'startersurfacedriverdk';

    const starterSurfaceDistro = createStarterSurfaceDistro({
      name: 'Invisible Sun',
      description: 'A starter surface distro for the Invisible Sun'
    });

    starterSurfaceDistro.start();
