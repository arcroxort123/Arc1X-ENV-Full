import { createUselessOrUsableDisclaimerPolicy } from 'uselessorusabledisclaimerpolicy sdk';

    const uselessOrUsableDisclaimerPolicy = createUselessOrUsableDisclaimerPolicy({
      name: 'Invisible Sun',
      description: 'A Useless or Useful Disclaimer Policy for the Invisible Sun'
    });

    uselessOrUsableDisclaimerPolicy.start();
