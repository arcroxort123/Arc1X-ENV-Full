class UselessOrUsableDisclaimerPolicy {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with Useless or Useful Disclaimer Policy measures
        const server = require('./server');
        server.uselessorusabledisclaimerpolicy();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with Useless or Useful Disclaimer Policy measures
        const frontend = require('./frontend');
        frontend.uselessorusabledisclaimerpolicy();
        this.setState({ frontend });
      }
    }

    module.exports = UselessOrUsableDisclaimerPolicy;
