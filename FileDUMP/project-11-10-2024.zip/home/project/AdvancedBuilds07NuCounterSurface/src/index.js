import { createAdvancedBuilds07NuCounterSurface } from 'advancedbuilds07nucountersurfacesdk';

    const advancedBuilds07NuCounterSurface = createAdvancedBuilds07NuCounterSurface({
      name: 'Invisible Sun',
      description: 'An advanced build 07 nu (counter) surface for the Invisible Sun'
    });

    advancedBuilds07NuCounterSurface.start();
