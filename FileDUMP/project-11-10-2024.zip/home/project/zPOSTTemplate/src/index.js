import { createZPOSTTemplate } from 'zposttemplateldk';

    const zPOSTTemplate = createZPOSTTemplate({
      name: 'Invisible Sun',
      description: 'A zPOST TEMPLATE for the Invisible Sun'
    });

    zPOSTTemplate.start();
