class ZPOSTTemplate {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with zPOST TEMPLATE measures
        const server = require('./server');
        server.zposttemplate();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with zPOST TEMPLATE measures
        const frontend = require('./frontend');
        frontend.zposttemplate();
        this.setState({ frontend });
      }
    }

    module.exports = ZPOSTTemplate;
