class 04WipExtrasRemissionChapter8DynamoToProsper {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with dynamo to prosper measures
        const server = require('./server');
        server.04wipextrasremissionchapter8dynamotoprosper();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with dynamo to prosper measures
        const frontend = require('./frontend');
        frontend.04wipextrasremissionchapter8dynamotoprosper();
        this.setState({ frontend });
      }
    }

    module.exports = 04WipExtrasRemissionChapter8DynamoToProsper;
