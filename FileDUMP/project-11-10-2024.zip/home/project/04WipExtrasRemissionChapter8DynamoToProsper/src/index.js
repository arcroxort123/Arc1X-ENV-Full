import { create04WipExtrasRemissionChapter8DynamoToProsper } from '04wipextrasremissionchapter8dynamotoprosperdk';

    const 04WipExtrasRemissionChapter8DynamoToProsper = create04WipExtrasRemissionChapter8DynamoToProsper({
      name: 'Invisible Sun',
      description: 'A dynamo to prosper for the 04 Wip Extras Remission Chapter 8'
    });

    04WipExtrasRemissionChapter8DynamoToProsper.start();
