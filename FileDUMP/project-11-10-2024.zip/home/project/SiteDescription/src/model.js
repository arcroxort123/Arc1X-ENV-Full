class SiteDescription {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with site description measures
        const server = require('./server');
        server.sitesdescription();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with site description measures
        const frontend = require('./frontend');
        frontend.sitesdescription();
        this.setState({ frontend });
      }
    }

    module.exports = SiteDescription;
