import { createSiteDescription } from 'sitesdescriptiondk';

    const siteDescription = createSiteDescription({
      name: 'Invisible Sun',
      description: 'A site description for the Invisible Sun'
    });

    siteDescription.start();
