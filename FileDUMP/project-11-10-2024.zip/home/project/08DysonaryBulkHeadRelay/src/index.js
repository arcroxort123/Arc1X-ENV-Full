import { createDysonaryBulkHeadRelay } from 'dysonarybulkheadrelaydk';

    const dysonaryBulkHeadRelay = createDysonaryBulkHeadRelay({
      name: 'Invisible Sun',
      description: 'A dysonary bulk head relay for the Invisible Sun'
    });

    dysonaryBulkHeadRelay.start();
