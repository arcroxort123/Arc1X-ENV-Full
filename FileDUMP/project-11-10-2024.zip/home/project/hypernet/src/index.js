import { createHypernet } from 'hypernet-sdk';

    const hypernet = createHypernet({
      name: 'Invisible Sun',
      description: 'A hypernet for the Invisible Sun'
    });

    hypernet.start();
