class MainExtrasReferencesRemission {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with references (remission) measures
        const server = require('./server');
        server.mainextrasreferencesremission();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with references (remission) measures
        const frontend = require('./frontend');
        frontend.mainextrasreferencesremission();
        this.setState({ frontend });
      }
    }

    module.exports = MainExtrasReferencesRemission;
