import { createMainExtrasReferencesRemission } from 'mainextrasreferencesremisiondk';

    const mainExtrasReferencesRemission = createMainExtrasReferencesRemission({
      name: 'Invisible Sun',
      description: 'A references (remission) for the MAIN Extras'
    });

    mainExtrasReferencesRemission.start();
