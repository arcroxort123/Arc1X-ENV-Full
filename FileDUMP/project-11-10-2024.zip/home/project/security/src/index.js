import { createSecurity } from 'security-sdk';

    const security = createSecurity({
      name: 'Invisible Sun',
      description: 'A security for the Invisible Sun'
    });

    security.start();
