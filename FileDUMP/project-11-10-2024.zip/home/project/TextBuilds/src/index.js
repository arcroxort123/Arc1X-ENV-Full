import { createTextBuilds } from 'textbuildsdk';

    const textBuilds = createTextBuilds({
      name: 'Invisible Sun',
      description: 'A text build for the Invisible Sun'
    });

    textBuilds.start();
