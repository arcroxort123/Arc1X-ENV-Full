class SolarRaspberryDroneCam {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with Solar Raspberry DroneCam measures
        const server = require('./server');
        server.solarraspberrydronecam();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with Solar Raspberry DroneCam measures
        const frontend = require('./frontend');
        frontend.solarraspberrydronecam();
        this.setState({ frontend });
      }
    }

    module.exports = SolarRaspberryDroneCam;
