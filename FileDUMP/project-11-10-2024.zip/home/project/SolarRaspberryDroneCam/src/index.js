import { createSolarRaspberryDroneCam } from 'solarraspberrydronecamdk';

    const solarRaspberryDroneCam = createSolarRaspberryDroneCam({
      name: 'Invisible Sun',
      description: 'A Solar Raspberry DroneCam for the Invisible Sun'
    });

    solarRaspberryDroneCam.start();
