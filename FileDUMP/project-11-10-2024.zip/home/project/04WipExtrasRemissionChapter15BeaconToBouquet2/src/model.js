class 04WipExtrasRemissionChapter15BeaconToBouquet2 {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with beacon to bouquet 2 measures
        const server = require('./server');
        server.04wipextrasremissionchapter15beacontobouquet2();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with beacon to bouquet 2 measures
        const frontend = require('./frontend');
        frontend.04wipextrasremissionchapter15beacontobouquet2();
        this.setState({ frontend });
      }
    }

    module.exports = 04WipExtrasRemissionChapter15BeaconToBouquet2;
