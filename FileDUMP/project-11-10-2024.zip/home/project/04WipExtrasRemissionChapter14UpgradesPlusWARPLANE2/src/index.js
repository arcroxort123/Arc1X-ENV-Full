import { create04WipExtrasRemissionChapter14UpgradesPlusWARPLANE2 } from '04wipextrasremissionchapter14upgradespluswarplane2dk';

    const 04WipExtrasRemissionChapter14UpgradesPlusWARPLANE2 = create04WipExtrasRemissionChapter14UpgradesPlusWARPLANE2({
      name: 'Invisible Sun',
      description: 'An upgrades plus WARPLANE 2 for the 04 Wip Extras Remission Chapter 14'
    });

    04WipExtrasRemissionChapter14UpgradesPlusWARPLANE2.start();
