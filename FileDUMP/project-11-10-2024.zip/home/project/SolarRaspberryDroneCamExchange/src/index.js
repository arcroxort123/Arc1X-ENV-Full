import { createSolarRaspberryDroneCamExchange } from 'solarraspberrydronecamexchangesdk';

    const solarRaspberryDroneCamExchange = createSolarRaspberryDroneCamExchange({
      name: 'Invisible Sun',
      description: 'A Solar Raspberry DroneCam Exchange for the Invisible Sun'
    });

    solarRaspberryDroneCamExchange.start();
