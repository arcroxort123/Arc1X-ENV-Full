class SolarRaspberryDroneCamExchange {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with Solar Raspberry DroneCam Exchange measures
        const server = require('./server');
        server.solarraspberrydronecamexchange();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with Solar Raspberry DroneCam Exchange measures
        const frontend = require('./frontend');
        frontend.solarraspberrydronecamexchange();
        this.setState({ frontend });
      }
    }

    module.exports = SolarRaspberryDroneCamExchange;
