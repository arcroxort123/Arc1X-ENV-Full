class Logging {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with logging measures
        const server = require('./server');
        server.logging();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with logging measures
        const frontend = require('./frontend');
        frontend.logging();
        this.setState({ frontend });
      }
    }

    module.exports = Logging;
