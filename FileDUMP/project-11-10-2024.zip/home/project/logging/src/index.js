import { createLogging } from 'logging-sdk';

    const logging = createLogging({
      name: 'Invisible Sun',
      description: 'A logging for the Invisible Sun'
    });

    logging.start();
