class 04WipExtrasRemissionChapter12WoopsieForgotThese {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with woopsie forgot these measures
        const server = require('./server');
        server.04wipextrasremissionchapter12woopsieforgotthese();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with woopsie forgot these measures
        const frontend = require('./frontend');
        frontend.04wipextrasremissionchapter12woopsieforgotthese();
        this.setState({ frontend });
      }
    }

    module.exports = 04WipExtrasRemissionChapter12WoopsieForgotThese;
