import { create04WipExtrasRemissionChapter12WoopsieForgotThese } from '04wipextrasremissionchapter12woopsieforgotthese dk';

    const 04WipExtrasRemissionChapter12WoopsieForgotThese = create04WipExtrasRemissionChapter12WoopsieForgotThese({
      name: 'Invisible Sun',
      description: 'A woopsie forgot these for the 04 Wip Extras Remission Chapter 12'
    });

    04WipExtrasRemissionChapter12WoopsieForgotThese.start();
