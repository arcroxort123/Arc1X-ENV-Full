import { createAdvancedBuilds04ParticleComputer } from 'advancedbuilds04particlecomputerdk';

    const advancedBuilds04ParticleComputer = createAdvancedBuilds04ParticleComputer({
      name: 'Invisible Sun',
      description: 'An advanced build 04 particle computer for the Invisible Sun'
    });

    advancedBuilds04ParticleComputer.start();
