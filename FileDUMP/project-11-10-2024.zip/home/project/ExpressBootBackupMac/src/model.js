class ExpressBootBackupMac {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with express boot backup mac measures
        const server = require('./server');
        server.expressbootbackupmac();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with express boot backup mac measures
        const frontend = require('./frontend');
        frontend.expressbootbackupmac();
        this.setState({ frontend });
      }
    }

    module.exports = ExpressBootBackupMac;
