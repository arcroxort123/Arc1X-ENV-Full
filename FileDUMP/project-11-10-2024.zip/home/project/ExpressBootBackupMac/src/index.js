import { createExpressBootBackupMac } from 'expressbootbackupmackdk';

    const expressBootBackupMac = createExpressBootBackupMac({
      name: 'Invisible Sun',
      description: 'An express boot backup mac for the Invisible Sun'
    });

    expressBootBackupMac.start();
