import { createDeployment } from 'deployment-sdk';

    const deployment = createDeployment({
      name: 'Invisible Sun',
      description: 'A deployment for the Invisible Sun'
    });

    deployment.start();
