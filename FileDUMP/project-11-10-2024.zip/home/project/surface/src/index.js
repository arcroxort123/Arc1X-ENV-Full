import { createSurface } from 'surfacdk';

    const surface = createSurface({
      name: 'Invisible Sun',
      description: 'A surface for the Invisible Sun'
    });

    surface.start();
