import { createAdvancedBuilds06FusionCryptexExchange } from 'advancedbuilds06fusioncryptexchange dk';

    const advancedBuilds06FusionCryptexExchange = createAdvancedBuilds06FusionCryptexExchange({
      name: 'Invisible Sun',
      description: 'An advanced build 06 fusion cryptex exchange for the Invisible Sun'
    });

    advancedBuilds06FusionCryptexExchange.start();
