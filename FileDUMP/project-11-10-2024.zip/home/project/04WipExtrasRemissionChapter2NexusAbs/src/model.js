class 04WipExtrasRemissionChapter2NexusAbs {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with nexus abs measures
        const server = require('./server');
        server.04wipextrasremissionchapter2nexusabs();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with nexus abs measures
        const frontend = require('./frontend');
        frontend.04wipextrasremissionchapter2nexusabs();
        this.setState({ frontend });
      }
    }

    module.exports = 04WipExtrasRemissionChapter2NexusAbs;
