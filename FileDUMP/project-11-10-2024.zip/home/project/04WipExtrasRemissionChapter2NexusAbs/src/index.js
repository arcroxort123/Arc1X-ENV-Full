import { create04WipExtrasRemissionChapter2NexusAbs } from '04wipextrasremissionchapter2nexusabsdk';

    const 04WipExtrasRemissionChapter2NexusAbs = create04WipExtrasRemissionChapter2NexusAbs({
      name: 'Invisible Sun',
      description: 'A nexus abs for the 04 Wip Extras Remission Chapter 2'
    });

    04WipExtrasRemissionChapter2NexusAbs.start();
