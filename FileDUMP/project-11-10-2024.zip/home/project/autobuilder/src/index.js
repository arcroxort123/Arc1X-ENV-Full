import { createAutobuilder } from 'autobuilder-sdk';

    const autobuilder = createAutobuilder({
      name: 'Invisible Sun',
      description: 'An autobuilder for the Invisible Sun'
    });

    autobuilder.start();
