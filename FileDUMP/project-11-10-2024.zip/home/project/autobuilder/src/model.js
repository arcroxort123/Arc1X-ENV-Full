import { createConverter } from 'converter-sdk';

    const converter = createConverter({
      name: 'Invisible Sun',
      description: 'A converter for the Invisible Sun'
    });

    converter.start();
