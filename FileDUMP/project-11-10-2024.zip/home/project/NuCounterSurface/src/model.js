class NuCounterSurface {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with Nu (Counter) surface measures
        const server = require('./server');
        server.nucountersurface();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with Nu (Counter) surface measures
        const frontend = require('./frontend');
        frontend.nucountersurface();
        this.setState({ frontend });
      }
    }

    module.exports = NuCounterSurface;
