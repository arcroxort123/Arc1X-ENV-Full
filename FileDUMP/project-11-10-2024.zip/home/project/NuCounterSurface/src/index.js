import { createNuCounterSurface } from 'nucountersurfacesdk';

    const nuCounterSurface = createNuCounterSurface({
      name: 'Invisible Sun',
      description: 'A Nu (Counter) surface for the Invisible Sun'
    });

    nuCounterSurface.start();
