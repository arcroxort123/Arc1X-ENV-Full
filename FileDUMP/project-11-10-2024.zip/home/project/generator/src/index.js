import { createGenerator } from 'generator-sdk';

    const generator = createGenerator({
      name: 'Invisible Sun',
      description: 'A generator for the Invisible Sun'
    });

    generator.start();
