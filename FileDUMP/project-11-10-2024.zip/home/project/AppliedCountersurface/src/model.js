class AppliedCountersurface {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with applied countersurface measures
        const server = require('./server');
        server.appliedcountersurface();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with applied countersurface measures
        const frontend = require('./frontend');
        frontend.appliedcountersurface();
        this.setState({ frontend });
      }
    }

    module.exports = AppliedCountersurface;
