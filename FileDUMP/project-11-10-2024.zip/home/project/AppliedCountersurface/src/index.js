import { createAppliedCountersurface } from 'appliedcountersurfacesdk';

    const appliedCountersurface = createAppliedCountersurface({
      name: 'Invisible Sun',
      description: 'An applied countersurface for the Invisible Sun'
    });

    appliedCountersurface.start();
