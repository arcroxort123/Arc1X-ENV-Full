import { createQuantumReadyComputationProfile } from 'quantumreadycomputationprofile sdk';

    const quantumReadyComputationProfile = createQuantumReadyComputationProfile({
      name: 'Invisible Sun',
      description: 'A QuantumReady Computation Profile for the Invisible Sun'
    });

    quantumReadyComputationProfile.start();
