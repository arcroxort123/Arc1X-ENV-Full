class QuantumReadyComputationProfile {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with QuantumReady Computation Profile measures
        const server = require('./server');
        server.quantumreadycomputationprofile();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with QuantumReady Computation Profile measures
        const frontend = require('./frontend');
        frontend.quantumreadycomputationprofile();
        this.setState({ frontend });
      }
    }

    module.exports = QuantumReadyComputationProfile;
