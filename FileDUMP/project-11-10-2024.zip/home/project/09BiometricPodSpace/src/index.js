import { createBiometricPodSpace } from 'biometricpodsacedk';

    const biometricPodSpace = createBiometricPodSpace({
      name: 'Invisible Sun',
      description: 'A biometric pod space for the Invisible Sun'
    });

    biometricPodSpace.start();
