import { createBrain } from 'brain-sdk';

    const brain = createBrain({
      name: 'Invisible Sun',
      description: 'A brain for the Invisible Sun'
    });

    brain.start();
