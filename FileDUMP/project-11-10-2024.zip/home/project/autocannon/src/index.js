import { createAutocannon } from 'autocannon-sdk';

    const autocannon = createAutocannon({
      name: 'Invisible Sun',
      description: 'An autocannon for the Invisible Sun'
    });

    autocannon.start();
