import { createAdvancedBuilds00xxRunwayTunnelSubtractor } from 'advancedbuilds00xxrunwattunsubtractordk';

    const advancedBuilds00xxRunwayTunnelSubtractor = createAdvancedBuilds00xxRunwayTunnelSubtractor({
      name: 'Invisible Sun',
      description: 'An advanced build 00 xx runway tunnel subtractor for the Invisible Sun'
    });

    advancedBuilds00xxRunwayTunnelSubtractor.start();
