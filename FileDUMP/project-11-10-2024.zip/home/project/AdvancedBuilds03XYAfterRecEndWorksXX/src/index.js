import { createAdvancedBuilds03XYAfterRecEndWorksXX } from 'advancedbuilds03xyafterrecendworksexxxdk';

    const advancedBuilds03XYAfterRecEndWorksXX = createAdvancedBuilds03XYAfterRecEndWorksXX({
      name: 'Invisible Sun',
      description: 'An advanced build 03 xy after rec end works xx for the Invisible Sun'
    });

    advancedBuilds03XYAfterRecEndWorksXX.start();
