import { createExtrasPerks } from 'extrasperksdk';

    const extrasPerks = createExtrasPerks({
      name: 'Invisible Sun',
      description: 'An extras perks for the Invisible Sun'
    });

    extrasPerks.start();
