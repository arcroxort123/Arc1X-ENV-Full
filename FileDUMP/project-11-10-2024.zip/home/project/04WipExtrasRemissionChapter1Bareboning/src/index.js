import { create04WipExtrasRemissionChapter1Bareboning } from '04wipextrasremissionchapter1bareboningdk';

    const 04WipExtrasRemissionChapter1Bareboning = create04WipExtrasRemissionChapter1Bareboning({
      name: 'Invisible Sun',
      description: 'A bareboning for the 04 Wip Extras Remission Chapter 1'
    });

    04WipExtrasRemissionChapter1Bareboning.start();
