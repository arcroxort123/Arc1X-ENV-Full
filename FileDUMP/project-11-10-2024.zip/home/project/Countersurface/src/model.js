class Countersurface {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with countersurface measures
        const server = require('./server');
        server.countersurface();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with countersurface measures
        const frontend = require('./frontend');
        frontend.countersurface();
        this.setState({ frontend });
      }
    }

    module.exports = Countersurface;
