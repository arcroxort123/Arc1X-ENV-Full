import { createCountersurface } from 'countersurfacesdk';

    const countersurface = createCountersurface({
      name: 'Invisible Sun',
      description: 'A countersurface for the Invisible Sun'
    });

    countersurface.start();
