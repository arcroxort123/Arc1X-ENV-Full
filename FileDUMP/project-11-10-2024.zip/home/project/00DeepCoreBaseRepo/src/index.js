import { createDeepCoreBaseRepo } from 'deepcorebaserepodk';

    const deepCoreBaseRepo = createDeepCoreBaseRepo({
      name: 'Invisible Sun',
      description: 'A deep core base repo for the Invisible Sun'
    });

    deepCoreBaseRepo.start();
