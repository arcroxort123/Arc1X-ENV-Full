import { create04WipExtrasRemissionChapter3ProxyMarket } from '04wipextrasremissionchapter3proxymarketdk';

    const 04WipExtrasRemissionChapter3ProxyMarket = create04WipExtrasRemissionChapter3ProxyMarket({
      name: 'Invisible Sun',
      description: 'A proxy market for the 04 Wip Extras Remission Chapter 3'
    });

    04WipExtrasRemissionChapter3ProxyMarket.start();
