class FusionCryptexExchange {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with Fusion Cryptex exchange measures
        const server = require('./server');
        server.fusioncryptexchange();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with Fusion Cryptex exchange measures
        const frontend = require('./frontend');
        frontend.fusioncryptexchange();
        this.setState({ frontend });
      }
    }

    module.exports = FusionCryptexExchange;
