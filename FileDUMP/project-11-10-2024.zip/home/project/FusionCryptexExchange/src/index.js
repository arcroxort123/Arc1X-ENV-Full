import { createFusionCryptexExchange } from 'fusioncryptexchange sdk';

    const fusionCryptexExchange = createFusionCryptexExchange({
      name: 'Invisible Sun',
      description: 'A Fusion Cryptex exchange for the Invisible Sun'
    });

    fusionCryptexExchange.start();
