import { create04WipExtrasRemissionChapter6Predispositions } from '04wipextrasremissionchapter6predispositionsdk';

    const 04WipExtrasRemissionChapter6Predispositions = create04WipExtrasRemissionChapter6Predispositions({
      name: 'Invisible Sun',
      description: 'A predispositions for the 04 Wip Extras Remission Chapter 6'
    });

    04WipExtrasRemissionChapter6Predispositions.start();
