class 04WipExtrasRemissionChapter6Predispositions {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with predispositions measures
        const server = require('./server');
        server.04wipextrasremissionchapter6predispositions();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with predispositions measures
        const frontend = require('./frontend');
        frontend.04wipextrasremissionchapter6predispositions();
        this.setState({ frontend });
      }
    }

    module.exports = 04WipExtrasRemissionChapter6Predispositions;
