import { createMacroAutoBuilder } from 'macroautobuilderdk';

    const macroAutoBuilder = createMacroAutoBuilder({
      name: 'Invisible Sun',
      description: 'A macro auto builder for the Invisible Sun'
    });

    macroAutoBuilder.start();
