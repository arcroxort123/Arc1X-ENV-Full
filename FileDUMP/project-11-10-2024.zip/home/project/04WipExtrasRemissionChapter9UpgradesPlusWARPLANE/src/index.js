import { create04WipExtrasRemissionChapter9UpgradesPlusWARPLANE } from '04wipextrasremissionchapter9upgradespluswarplanedk';

    const 04WipExtrasRemissionChapter9UpgradesPlusWARPLANE = create04WipExtrasRemissionChapter9UpgradesPlusWARPLANE({
      name: 'Invisible Sun',
      description: 'An upgrades plus WARPLANE for the 04 Wip Extras Remission Chapter 9'
    });

    04WipExtrasRemissionChapter9UpgradesPlusWARPLANE.start();
