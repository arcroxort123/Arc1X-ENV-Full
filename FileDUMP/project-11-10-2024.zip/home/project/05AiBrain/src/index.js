import { createAiBrain } from 'aibraindk';

    const aiBrain = createAiBrain({
      name: 'Invisible Sun',
      description: 'An ai brain for the Invisible Sun'
    });

    aiBrain.start();
