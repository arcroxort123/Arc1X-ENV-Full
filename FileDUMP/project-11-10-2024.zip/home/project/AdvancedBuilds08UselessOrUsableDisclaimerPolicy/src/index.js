import { createAdvancedBuilds08UselessOrUsableDisclaimerPolicy } from 'advancedbuilds08uselessorusabledisclaimerpolicydk';

    const advancedBuilds08UselessOrUsableDisclaimerPolicy = createAdvancedBuilds08UselessOrUsableDisclaimerPolicy({
      name: 'Invisible Sun',
      description: 'An advanced build 08 useless or useful disclaimer policy you decide for the Invisible Sun'
    });

    advancedBuilds08UselessOrUsableDisclaimerPolicy.start();
