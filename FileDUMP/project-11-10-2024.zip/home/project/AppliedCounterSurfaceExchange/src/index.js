import { createAppliedCounterSurfaceExchange } from 'appliedcountersurfaceexchange sdk';

    const appliedCounterSurfaceExchange = createAppliedCounterSurfaceExchange({
      name: 'Invisible Sun',
      description: 'An Applied Counter Surface Exchange for the Invisible Sun'
    });

    appliedCounterSurfaceExchange.start();
