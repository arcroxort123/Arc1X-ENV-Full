class AppliedCounterSurfaceExchange {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with Applied Counter Surface Exchange measures
        const server = require('./server');
        server.appliedcountersurfaceexchange();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with Applied Counter Surface Exchange measures
        const frontend = require('./frontend');
        frontend.appliedcountersurfaceexchange();
        this.setState({ frontend });
      }
    }

    module.exports = AppliedCounterSurfaceExchange;
