import { createXYAfterRecEndworksXX } from 'xyafterrecendworksexxx sdk';

    const xyAfterRecEndworksXX = createXYAfterRecEndworksXX({
      name: 'Invisible Sun',
      description: 'An XY After Rec EndWorks XX for the Invisible Sun'
    });

    xyAfterRecEndworksXX.start();
