class XYAfterRecEndworksXX {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with XY After Rec EndWorks XX measures
        const server = require('./server');
        server.xyafterrecendworksexxx();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with XY After Rec EndWorks XX measures
        const frontend = require('./frontend');
        frontend.xyafterrecendworksexxx();
        this.setState({ frontend });
      }
    }

    module.exports = XYAfterRecEndworksXX;
