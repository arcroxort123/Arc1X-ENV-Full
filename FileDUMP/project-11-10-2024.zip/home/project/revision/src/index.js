import { createRevision } from 'revision-sdk';

    const revision = createRevision({
      name: 'Invisible Sun',
      description: 'A revision for the Invisible Sun'
    });

    revision.start();
