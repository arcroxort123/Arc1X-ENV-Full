import { createAdvancedBuilds } from 'advancedbuildsdk';

    const advancedBuilds = createAdvancedBuilds({
      name: 'Invisible Sun',
      description: 'An advanced build for the Invisible Sun'
    });

    advancedBuilds.start();
