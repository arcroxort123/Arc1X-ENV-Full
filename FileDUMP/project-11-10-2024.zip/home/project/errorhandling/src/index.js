import { createErrorHandling } from 'errorhandling-sdk';

    const errorHandling = createErrorHandling({
      name: 'Invisible Sun',
      description: 'An error handling for the Invisible Sun'
    });

    errorHandling.start();
