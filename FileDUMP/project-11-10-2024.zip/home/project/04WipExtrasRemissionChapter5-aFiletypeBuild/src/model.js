class 04WipExtrasRemissionChapter5aFiletypeBuild {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with filetype build measures
        const server = require('./server');
        server.04wipextrasremissionchapter5afiletypebuild();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with filetype build measures
        const frontend = require('./frontend');
        frontend.04wipextrasremissionchapter5afiletypebuild();
        this.setState({ frontend });
      }
    }

    module.exports = 04WipExtrasRemissionChapter5aFiletypeBuild;
