import { create04WipExtrasRemissionChapter5aFiletypeBuild } from '04wipextrasremissionchapter5afiletypebuilddk';

    const 04WipExtrasRemissionChapter5aFiletypeBuild = create04WipExtrasRemissionChapter5aFiletypeBuild({
      name: 'Invisible Sun',
      description: 'A filetype build for the 04 Wip Extras Remission Chapter 5'
    });

    04WipExtrasRemissionChapter5aFiletypeBuild.start();
