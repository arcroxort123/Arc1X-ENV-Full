import { createAdvancedBuilds05SolarRaspberryDroneCam } from 'advancedbuilds05solarraspberrydronecamdk';

    const advancedBuilds05SolarRaspberryDroneCam = createAdvancedBuilds05SolarRaspberryDroneCam({
      name: 'Invisible Sun',
      description: 'An advanced build 05 solar raspberry drone cam for the Invisible Sun'
    });

    advancedBuilds05SolarRaspberryDroneCam.start();
