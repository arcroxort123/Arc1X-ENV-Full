import { createBridge } from 'bridge-sdk';

    const bridge = createBridge({
      name: 'Invisible Sun',
      description: 'A bridge to the Invisible Sun'
    });

    bridge.start();
