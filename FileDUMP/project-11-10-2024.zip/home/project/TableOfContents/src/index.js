import { createTableOfContents } from 'tableofcontentsdk';

    const tableOfContents = createTableOfContents({
      name: 'Invisible Sun',
      description: 'A table of contents for the Invisible Sun'
    });

    tableOfContents.start();
