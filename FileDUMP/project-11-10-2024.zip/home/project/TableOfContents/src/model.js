class TableOfContents {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with table of contents measures
        const server = require('./server');
        server.tableofcontents();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with table of contents measures
        const frontend = require('./frontend');
        frontend.tableofcontents();
        this.setState({ frontend });
      }
    }

    module.exports = TableOfContents;
