class 04WipExtrasRemissioChapter1Bareboning {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with bareboning measures
        const server = require('./server');
        server.04wipextrasremissionchapter1bareboning();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with bareboning measures
        const frontend = require('./frontend');
        frontend.04wipextrasremissionchapter1bareboning();
        this.setState({ frontend });
      }
    }

    module.exports = 04WipExtrasRemissioChapter1Bareboning;
