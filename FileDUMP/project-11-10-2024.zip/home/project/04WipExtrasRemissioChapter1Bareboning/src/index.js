import { create04WipExtrasRemissioChapter1Bareboning } from '04wipextrasremissionchapter1bareboningdk';

    const 04WipExtrasRemissioChapter1Bareboning = create04WipExtrasRemissioChapter1Bareboning({
      name: 'Invisible Sun',
      description: 'A bareboning for the 04 Wip Extras Remissio Chapter 1'
    });

    04WipExtrasRemissioChapter1Bareboning.start();
