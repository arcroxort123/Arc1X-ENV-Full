import { createPrepSafeProtocol } from 'prep safeprotocol sdk';

    const prepSafeProtocol = createPrepSafeProtocol({
      name: 'Invisible Sun',
      description: 'A PREP SAFE PROTOCOL for the Invisible Sun'
    });

    prepSafeProtocol.start();
