class PrepSafeProtocol {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with PREP SAFE PROTOCOL measures
        const server = require('./server');
        server.prepsafeprotocol();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with PREP SAFE PROTOCOL measures
        const frontend = require('./frontend');
        frontend.prepsafeprotocol();
        this.setState({ frontend });
      }
    }

    module.exports = PrepSafeProtocol;
