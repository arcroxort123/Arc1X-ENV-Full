import { createTemplateLayout } from 'templatelayoutdk';

    const templateLayout = createTemplateLayout({
      name: 'Invisible Sun',
      description: 'A template layout for the Invisible Sun'
    });

    templateLayout.start();
