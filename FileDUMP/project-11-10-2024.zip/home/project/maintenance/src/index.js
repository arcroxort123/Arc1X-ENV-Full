import { createMaintenance } from 'maintenance-sdk';

    const maintenance = createMaintenance({
      name: 'Invisible Sun',
      description: 'A maintenance for the Invisible Sun'
    });

    maintenance.start();
