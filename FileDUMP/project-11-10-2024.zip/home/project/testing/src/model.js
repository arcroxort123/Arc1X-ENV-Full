class Testing {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server for testing
        const server = require('./server');
        server.testing();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend for testing
        const frontend = require('./frontend');
        frontend.testing();
        this.setState({ frontend });
      }
    }

    module.exports = Testing;
