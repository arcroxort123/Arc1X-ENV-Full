import { createTesting } from 'testing-sdk';

    const testing = createTesting({
      name: 'Invisible Sun',
      description: 'A testing for the Invisible Sun'
    });

    testing.start();
