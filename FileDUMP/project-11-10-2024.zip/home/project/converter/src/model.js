class Converter {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server
        const server = require('./server');
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend
        const frontend = require('./frontend');
        this.setState({ frontend });
      }
    }

    module.exports = Converter;
