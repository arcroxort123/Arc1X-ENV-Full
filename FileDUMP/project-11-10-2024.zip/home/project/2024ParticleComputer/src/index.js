import { create2024ParticleComputer } from '2024particlecomputersdk';

    const 2024ParticleComputer = create2024ParticleComputer({
      name: 'Invisible Sun',
      description: 'A 2024 particle computer for the Invisible Sun'
    });

    2024ParticleComputer.start();
