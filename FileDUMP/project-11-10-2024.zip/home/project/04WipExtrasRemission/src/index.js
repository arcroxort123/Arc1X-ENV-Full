import { create04WipExtrasRemission } from '04wipextrasremissiondk';

    const 04WipExtrasRemission = create04WipExtrasRemission({
      name: 'Invisible Sun',
      description: 'A wip extras remission for the Invisible Sun'
    });

    04WipExtrasRemission.start();
