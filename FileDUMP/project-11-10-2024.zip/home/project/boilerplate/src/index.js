import { createBoilerplate } from 'boilerplate-sdk';

    const boilerplate = createBoilerplate({
      name: 'Invisible Sun',
      description: 'A boilerplate for the Invisible Sun'
    });

    boilerplate.start();
