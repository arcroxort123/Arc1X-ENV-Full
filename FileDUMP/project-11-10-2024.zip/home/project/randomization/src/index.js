import { createRandomizer } from 'randomizer-sdk';

    const randomizer = createRandomizer({
      name: 'Invisible Sun',
      description: 'A randomizer for the Invisible Sun'
    });

    randomizer.start();
