import { createAfterMathLoadOut } from 'aftermathloadoutdk';

    const afterMathLoadOut = createAfterMathLoadOut({
      name: 'Invisible Sun',
      description: 'An after math load out for the Invisible Sun'
    });

    afterMathLoadOut.start();
