class AfterMathLoadOut {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with after math load out measures
        const server = require('./server');
        server.aftermathloadout();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with after math load out measures
        const frontend = require('./frontend');
        frontend.aftermathloadout();
        this.setState({ frontend });
      }
    }

    module.exports = AfterMathLoadOut;
