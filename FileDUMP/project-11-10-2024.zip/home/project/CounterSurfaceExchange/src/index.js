import { createCounterSurfaceExchange } from 'countersurfaceexchange sdk';

    const counterSurfaceExchange = createCounterSurfaceExchange({
      name: 'Invisible Sun',
      description: 'A Counter Surface Exchange for the Invisible Sun'
    });

    counterSurfaceExchange.start();
