class CounterSurfaceExchange {
      constructor() {
        this.state = {
          server: null,
          frontend: null
        };
      }

      startServer() {
        // Start the server with Counter Surface Exchange measures
        const server = require('./server');
        server.countersurfaceexchange();
        this.setState({ server });
      }

      startFrontend() {
        // Start the frontend with Counter Surface Exchange measures
        const frontend = require('./frontend');
        frontend.countersurfaceexchange();
        this.setState({ frontend });
      }
    }

    module.exports = CounterSurfaceExchange;
