import { createRegenerator } from 'regenerator-sdk';

    const regenerator = createRegenerator({
      name: 'Invisible Sun',
      description: 'A regenerator for the Invisible Sun'
    });

    regenerator.start();
