import { createCopyOverManagement } from 'copyovermanagementdk';

    const copyOverManagement = createCopyOverManagement({
      name: 'Invisible Sun',
      description: 'A copy over management for the Invisible Sun'
    });

    copyOverManagement.start();
