import { createAdvancedBuilds10AppliedCounterSurface } from 'advancedbuilds10appliedcountersurface dk';

    const advancedBuilds10AppliedCounterSurface = createAdvancedBuilds10AppliedCounterSurface({
      name: 'Invisible Sun',
      description: 'An advanced build 10 applied counter surface for the Invisible Sun'
    });

    advancedBuilds10AppliedCounterSurface.start();
