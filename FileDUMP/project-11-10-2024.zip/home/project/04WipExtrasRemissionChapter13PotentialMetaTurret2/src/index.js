import { create04WipExtrasRemissionChapter13PotentialMetaTurret2 } from '04wipextrasremissionchapter13potentialmetaturret2dk';

    const 04WipExtrasRemissionChapter13PotentialMetaTurret2 = create04WipExtrasRemissionChapter13PotentialMetaTurret2({
      name: 'Invisible Sun',
      description: 'A potential meta turret 2 for the 04 Wip Extras Remission Chapter 13'
    });

    04WipExtrasRemissionChapter13PotentialMetaTurret2.start();
